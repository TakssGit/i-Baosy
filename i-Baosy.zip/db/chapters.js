const dbChapters = [
    {
        id: "elem_math_12_add",
        level: "12ème",
        series: null,
        subject: "Mathématiques",
        title: "Addition et Calcul Mental Élémentaire",
        summary: "Apprendre à regrouper les unités et les dizaines pour effectuer des additions simples.",
        lessons: [
            {
                title: "1. Le principe de l'addition",
                content: "L'addition consiste à assembler deux quantités. Exemple : 12 + 15 = (10 + 10) + (2 + 5) = 20 + 7 = 27."
            }
        ],
        practicalExercises: [
            {
                statement: "Calculez la somme : 24 + 35.",
                correction: "24 + 35 = (20 + 30) + (4 + 5) = 50 + 9 = 59."
            }
        ],
        questions: [
            {
                question: "Combien font 18 + 12 ?",
                options: ["28", "30", "32", "40"],
                correctAnswer: 1,
                explanation: "18 + 12 = 30. (8 + 2 = 10, et 10 + 10 + 10 = 30)."
            }
        ]
    },
    {
        id: "bepc_phys_3_electricite",
        level: "3ème",
        series: null,
        subject: "Physique-Chimie",
        title: "Loi d'Ohm et Circuits Électriques",
        summary: "Relation fondamentale entre la tension U, l'intensité I et la résistance R.",
        lessons: [
            {
                title: "1. Enoncé de la loi d'Ohm",
                content: "La tension U aux bornes d'un conducteur ohmique est proportionnelle à l'intensité I du courant qui le traverse : U = R x I."
            }
        ],
        practicalExercises: [
            {
                statement: "Une résistance R = 50 Ohms est traversée par un courant I = 0,2 A. Calculez la tension U à ses bornes.",
                correction: "D'après la loi d'Ohm, U = R x I = 50 x 0,2 = 10 Volts."
            }
        ],
        questions: [
            {
                question: "Quelle est l'unité de mesure de la résistance électrique ?",
                options: ["Volt (V)", "Ampère (A)", "Ohm (Ω)", "Watt (W)"],
                correctAnswer: 2,
                explanation: "La résistance électrique s'exprime en Ohms (symbole Ω)."
            }
        ]
    },
    {
        id: "term_math_c_complexes",
        level: "Terminale BACC",
        series: ["Série C", "Série D"],
        subject: "Mathématiques",
        title: "Nombres Complexes et Géométrie Vectorielle",
        summary: "Forme algébrique z = a + ib, forme trigonométrique et géométrie dans le plan complexe.",
        lessons: [
            {
                title: "1. Module d'un nombre complexe",
                content: "Le module de z = a + ib est le nombre réel positif |z| = sqrt(a² + b²)."
            }
        ],
        practicalExercises: [
            {
                statement: "Soit z = 1 + i*sqrt(3). Calculez le module |z| et déterminer son argument principal.",
                correction: "|z| = sqrt(1² + (sqrt(3))²) = sqrt(1 + 3) = 2. cos(θ) = 1/2 et sin(θ) = sqrt(3)/2, donc θ = π/3 rad."
            }
        ],
        questions: [
            {
                question: "Quel est le module de z = 3 + 4i ?",
                options: ["5", "7", "12", "25"],
                correctAnswer: 0,
                explanation: "|z| = sqrt(3² + 4²) = sqrt(9 + 16) = sqrt(25) = 5."
            }
        ]
    },
    {
        id: "term_philo_a_conscience",
        level: "Terminale BACC",
        series: ["Série A1", "Série A2"],
        subject: "Philosophie",
        title: "La Conscience, le Sujet et l'Inconscient",
        summary: "Analyse des théories cartésiennes de la conscience et de la psychanalyse freudienne.",
        lessons: [
            {
                title: "1. Le Cogito Cartésien",
                content: "Descartes établit le sujet comme certitude première : 'Je pense donc je suis' (Cogito ergo sum)."
            }
        ],
        practicalExercises: [
            {
                statement: "Expliquez en quoi la découverte de l'inconscient par Freud remet en cause la souveraineté du Cogito.",
                correction: "Freud affirme que 'le Moi n'est pas maître dans sa propre maison', montrant que des désirs inconscients échappent au contrôle de la conscience."
            }
        ],
        questions: [
            {
                question: "Qui est l'auteur de l'ouvrage 'L'Interprétation des Rêves' (1900) ?",
                options: ["René Descartes", "Jean-Paul Sartre", "Sigmund Freud", "Immanuel Kant"],
                correctAnswer: 2,
                explanation: "Sigmund Freud a écrit cet ouvrage fondateur de la psychanalyse."
            }
        ]
    },
    {
        id: "term_ses_ose_croissance",
        level: "Terminale BACC",
        series: ["Série OSE"],
        subject: "SES",
        title: "Les Sources de la Croissance Économique",
        summary: "Analyse du PIB, du progrès technique, des facteurs travail et capital.",
        lessons: [
            {
                title: "1. Facteurs de Production",
                content: "La croissance dépend de l'accumulation du facteur travail (population active) et du facteur capital (investissements)."
            }
        ],
        practicalExercises: [
            {
                statement: "Quelle est la différence entre croissance quantitative et développement durable ?",
                correction: "La croissance mesure l'augmentation du PIB, tandis que le développement intègre le bien-être social et la préservation de l'environnement."
            }
        ],
        questions: [
            {
                question: "Quel indicateur mesure l'augmentation de la richesse d'un pays sur une année ?",
                options: ["L'IDH", "Le PIB", "L'IPC", "La Balance Commerciale"],
                correctAnswer: 1,
                explanation: "Le Produit Intérieur Brut (PIB) mesure la valeur ajoutée totale produite dans un pays."
            }
        ]
    }
];
Commande ECHO d�sactiv�e.
// Consolidation globale pour la compatibilite de l'application
const schoolDatabase = {
    levels: dbMetadata.levels,
    baccSeries: dbMetadata.baccSeries,
    subjects: dbMetadata.subjects,
    chapters: dbChapters
};
